
package test;

import za.ac.tut.ui.BackendGui;




public class Test {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        BackendGui gui = new BackendGui();
        
    }
    
}
