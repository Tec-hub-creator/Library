
package za.ac.tut.ui;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class BackendGui extends JFrame {

    JPanel pOne = new JPanel();
    

    public BackendGui() {
        
        
        add(pOne);
        setTitle("My First Gui");
        setSize(400, 450);
        setResizable(true);
        setDefaultLookAndFeelDecorated(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setForeground(Color.red);
        setVisible(true);
        
    }
    


    
    
    
}
